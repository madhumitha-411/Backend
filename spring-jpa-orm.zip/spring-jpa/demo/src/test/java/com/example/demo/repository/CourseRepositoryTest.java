package com.example.demo.repository;

import com.example.demo.entity.Course;
import com.example.demo.entity.Student;
import com.example.demo.entity.Teacher;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.data.web.SpringDataWebProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;


import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
class CourseRepositoryTest {
    @Autowired
    private CourseRepository courseRepository;
    @Test
    public void printCourses(){
        List<Course> courses= courseRepository.findAll();
        System.out.println("courses = " + courses);
    }
    @Test
    public void saveCourseswithTeacher() {
        Teacher teachers = Teacher.builder().
                firstName("maya")
                .lastName("sharma")
                .build();
        Course course = Course.builder()
                .title("tech java")
                .credit(1)
                .teacher(teachers)
                .build();
        courseRepository.save(course);
    }
    @Test
    public void saveStudentwithTeacher(){
        Teacher teachers = Teacher.builder().
                firstName("lara")
                .lastName("ambani")
                .build();
        Student student=Student.builder()
                .firstName("harris")
                .lastName("jayaraj")
                .emailId("hj@gmail.com")
                .build();
        Course course = Course.builder()
                .title("sql")
                .credit(5)
                .teacher(teachers)
                .build();
        course.addStudent(student);
        courseRepository.save(course);
    }


}