package com.example.demo.repository;

import com.example.demo.entity.Course;
import com.example.demo.entity.Teacher;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
class TeacherRepositoryTest {

    @Autowired
    private TeacherRepository teacherRepository;
    @Test
    public void saveTeachers(){
        Course course = Course.builder().
                title("DBA").
                credit(5).
                build();
        Course course1 = Course.builder().
                title("BA").
                credit(2).
                build();
        Course course2 = Course.builder().
                title("AD").
                credit(1).
                build();
        Teacher teachers=Teacher.builder().
                firstName("simran")
                .lastName("bhalle")
                .courseData(List.of(course,course1,course2))
                .build();
        teacherRepository.save(teachers);
    }

}