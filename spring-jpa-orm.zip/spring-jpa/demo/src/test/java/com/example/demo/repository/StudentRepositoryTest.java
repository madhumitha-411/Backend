package com.example.demo.repository;
import java.util.*;

import com.example.demo.entity.Guardian;
import com.example.demo.entity.Student;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
class StudentRepositoryTest {
    @Autowired
    private StudentRepository studentRepository;

    @Test
    public void saveStudent() {
        Student student = Student.builder()
                .emailId("madhu@gmail.com")
                .firstName("Madhu")
                .lastName("Sighna")
//                 .guardianName("Sheela")
//                 .guardianEmail("sheela@gmail.com")
//                .guardianMobile("00000000")
                .build();
        studentRepository.save(student);

    }

    @Test
    public void saveStudentWithGuardian() {
        Guardian guardian = Guardian.builder().
                name("Heela")
                .email("Heela@gmail.com")
                .mobile("00000099").build();

        Student student = Student.builder().
                emailId("kj@gmail.com")
                .firstName("karan")
                .lastName("johar")
                .guardian(guardian)
                .build();
        studentRepository.save(student);
    }

    @Test
    public void printStudent() {
        List<Student> studentList = studentRepository.findAll();
        System.out.println("student = " + studentList);
    }

    @Test
    public void printStudentByFirstName() {
        List<Student> studentByName = studentRepository.findByFirstName("karan");
        System.out.println("student = " + studentByName);
    }

    @Test
    public void printStudentByFirstNameContaining() {
        List<Student> studentByNameContaining = studentRepository.findByFirstNameContaining("ka");
        System.out.println("student = " + studentByNameContaining);
    }

    @Test
    public void printStudentByGuardianName() {
        List<Student> studentByGuardianName = studentRepository.findByGuardianName("Sheela");
        System.out.println("student = " + studentByGuardianName);
    }

    @Test
    public void getStudentByEmailId() {
        Student studentByEmailId = studentRepository.getStudentByEmailId("kj@gmail.com");
        System.out.println("student = " + studentByEmailId);
    }

    @Test
    public void getStudentFirstNameByEmailId() {
        String studentFirstNameByEmailId = studentRepository.getStudentFirstNameByEmailId("kj@gmail.com");
        System.out.println("student = " + studentFirstNameByEmailId);
    }

    @Test
    public void getStudentLastNameByEmailId() {
        String studentLastNameByEmailId = studentRepository.getStudentLastNameByEmailId("kj@gmail.com");
        System.out.println("student = " + studentLastNameByEmailId);
    }

    @Test
    public void getStudentLastNameByEmailIdNamedParam() {
        String studentLastNameByEmailIdNP = studentRepository.getStudentLastNameByEmailIdNamedParam("kj@gmail.com");
        System.out.println("student = " + studentLastNameByEmailIdNP);
    }
    @Test
    public void updateStudentNameAndEmailId() {
        studentRepository.updateStudentNameAndEmailId(
               "ramesh","madhu@gmail.com"
        );

    }
}
