package com.example.demo.Service;
import java.util.*;
import com.example.demo.Entity.DepartmentEntity;
import com.example.demo.error.DepartmentNotFoundException;
import org.springframework.web.bind.annotation.PathVariable;

public interface DepartmentService {
    public DepartmentEntity saveDept(DepartmentEntity department);

    public List<DepartmentEntity> fetchDepartmentList();
    public DepartmentEntity fetchDepartmentById(Long id) throws DepartmentNotFoundException;

    public void deleteDepartmentById(Long departmentId);

    public DepartmentEntity update(Long departmentId, DepartmentEntity department);

  public DepartmentEntity fetchDepartmentByName(String departmentName);

}
