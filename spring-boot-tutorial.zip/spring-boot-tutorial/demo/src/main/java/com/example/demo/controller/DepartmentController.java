package com.example.demo.controller;
import java.util.List;
import com.example.demo.Entity.DepartmentEntity;
import com.example.demo.Service.DepartmentService;
import com.example.demo.error.DepartmentNotFoundException;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class DepartmentController {

@Autowired
    private DepartmentService departmentService;
private final Logger LOGGER = LoggerFactory.getLogger(DepartmentController.class);
    @PostMapping("/departments")
    public DepartmentEntity saveDept(@Valid @RequestBody DepartmentEntity department){
        LOGGER.info("inside saveDept in controller ");
        return departmentService.saveDept(department);
    }
    @GetMapping("/departments")
    public List<DepartmentEntity> fetchDepartmentList(){
        LOGGER.info("inside fetchDepartmentList in controller ");
          return departmentService.fetchDepartmentList();
    }
    @GetMapping("/departments/{id}")
    public DepartmentEntity fetchDepartmentById(@PathVariable("id") Long departmentId) throws DepartmentNotFoundException {
        return departmentService.fetchDepartmentById(departmentId);
    }
    @DeleteMapping("/departments/{id}")
    public String deleteDepartmentById(@PathVariable("id") Long departmentId){
        departmentService.deleteDepartmentById(departmentId);
        return "Deleted successfully!!!";
    }
    @PutMapping("/departments/{id}")
    public DepartmentEntity update(@PathVariable("id") Long departmentId, @RequestBody DepartmentEntity department){
        return departmentService.update(departmentId,department);
    }
    @GetMapping("/departments/name/{name}")
    public DepartmentEntity fetchDepartmentByName(@PathVariable("name") String departmentName){
        return departmentService.fetchDepartmentByName(departmentName);
    }
}
