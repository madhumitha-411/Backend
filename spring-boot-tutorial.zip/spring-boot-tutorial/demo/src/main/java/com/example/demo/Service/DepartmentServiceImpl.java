package com.example.demo.Service;
import java.util.*;
import com.example.demo.Entity.DepartmentEntity;
import com.example.demo.Repository.DepartmentRepository;
import com.example.demo.error.DepartmentNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

@Service
public class DepartmentServiceImpl implements DepartmentService{
    @Autowired
    private DepartmentRepository departmentRepository;
    @Override
    public DepartmentEntity saveDept(DepartmentEntity department){
        return departmentRepository.save((department));
    }
    @Override
    public List<DepartmentEntity> fetchDepartmentList(){
        return departmentRepository.findAll();
    }
    @Override
    public DepartmentEntity fetchDepartmentById(Long id) throws DepartmentNotFoundException {
        Optional<DepartmentEntity> department=departmentRepository.findById(id);
        if(!department.isPresent()){
            throw new DepartmentNotFoundException("Department not available!!!");
        }
        return department.get();
    }
    @Override
    public void deleteDepartmentById(Long departmentId){
        departmentRepository.deleteById(departmentId);
    }
    @Override
    public DepartmentEntity update(Long departmentId, DepartmentEntity department){
        DepartmentEntity depdb=departmentRepository.findById(departmentId).get();
        if(Objects.nonNull(department.getDepartmentName())&& !"".equalsIgnoreCase(department.getDepartmentName())){
            depdb.setDepartmentName(department.getDepartmentName());
        }
        if(Objects.nonNull(department.getDepartmentAddress())&& !"".equalsIgnoreCase(department.getDepartmentAddress())){
            depdb.setDepartmentAddress(department.getDepartmentAddress());
        }
        if(Objects.nonNull(department.getDepartmentCode())&& !"".equalsIgnoreCase(department.getDepartmentCode())){
            depdb.setDepartmentCode(department.getDepartmentCode());

        }
        return saveDept(depdb);
    }
    @Override
    public DepartmentEntity fetchDepartmentByName(String departmentName){
        return departmentRepository.findByDepartmentNameIgnoreCase(departmentName);
    }
}
